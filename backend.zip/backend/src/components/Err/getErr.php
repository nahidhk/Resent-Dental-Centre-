<?php
header('Content-Type: application/json');

$info = [
    "status" => "Get Null Error!"
];

echo json_encode($info);

?>