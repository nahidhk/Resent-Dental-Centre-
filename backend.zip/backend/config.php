<?php
<?php
// CORS headers
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

$host = "eu-host-1.championstack.com";
$user = "ndsqltop";
$pass = "(N@hid123$##)";
$db   = "ndsqltop_rds";

$conn = mysqli_connect($host, $user, $pass, $db);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// UTF-8 support
mysqli_set_charset($conn, "utf8mb4");
?>
